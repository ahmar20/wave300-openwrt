Requirements

Wireshark 1.6.1 or later should be installed.

Tested and worked on the following platforms:
  - Ubuntu 12.04 LTS 32-bit, Wireshark 1.6.5
  - Ubuntu 12.04 LTS 64-bit, Wireshark 1.6.7
  - Arch Linux 2011.08.19 32-bit, Wireshark 1.6.1

Installation

Run 'install.sh' stript as:
  sudo ./install.sh

Notes: try ./install.sh --help for more options.

Usage:
  rtlogger.sh <ip address>
