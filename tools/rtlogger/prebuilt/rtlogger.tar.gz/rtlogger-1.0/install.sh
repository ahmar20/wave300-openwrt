#!/bin/bash

script_name=$0
script_version=1.0
wireshark_name=wireshark
wireshark_min_version="1.6.1"
wireshark_pattern_plugin=asn1.so
wireshark_plugins_path_local=plugins
wireshark_plugin1=mtlklog.so
wireshark_plugin2=mtlklog.la
logcnv_binary=logcnv
logcnv_path_local=bin
logcnv_path=/usr/local/bin
rtlogger_binary=rtlogger.sh
rtlogger_path_local=bin
rtlogger_path=/usr/local/bin

function usage
{
    echo "RTLogger installation script"
    echo ""
    echo "Copyright (c) 2012 Lantiq Deutschland GmbH"
    echo ""
    echo "Usage: $script_name [parameters]..."
    echo ""
    echo "Supported parameters:"
    echo "  -v, --version                          show version"
    echo "  -h, --help                             show help message"
    echo "  -w, --wireshark-binary-path  <path>    force wireshark binary path"
    echo "  -p, --wireshark-plugins-path <path>    force wireshark plugins path"
    echo "  -e, --wireshark-version      <version> force wireshark version"
    echo "  -l, --logcnv-binary-path     <path>    force logcnv binary path"
    echo "  -r, --rtlogger-binary-path   <path>    force logcnv binary path"
    echo "  -b, --bits                   <number>  force bits (32 or 64)"
    exit 0
}

function do_install
{
    echo -n "Searching for $wireshark_name... "
    if [ -z "$wireshark_command" ]; then
        wireshark_command=`command -v $wireshark_name 2>&1` || { echo "failed" ; exit 1; }
        if [ -z "$wireshark_command" ]; then
            echo "failed"
            exit 1
        fi
    fi
    echo $wireshark_command

    echo -n "Checking $wireshark_name version... "
    if [ -z "$wireshark_version" ]; then
        wireshark_version=`$wireshark_name -v | head -n1 | awk '{print $2}'`
    fi
    # check version is not empty
    if [ -z "$wireshark_version" ]; then
        echo "failed"
        exit 1
    fi
    # check version for pattern
    case $wireshark_version in
        [[:digit:]][.][[:digit:]][.][[:digit:]]) : ;;
        *) echo "$wireshark_version failed"
            exit 1
            ;;
    esac
    echo $wireshark_version
    if [[ $wireshark_version < $wireshark_min_version ]]; then
        echo "Wireshark should be version >= $wireshark_min_version"; exit 1;
    fi

    echo -n "Searching for $wireshark_name plug-ins' directory... "
    if [ -z "$wireshark_plugins_path" ]; then
        wireshark_library_path=`echo "$wireshark_command" | sed 's/bin/lib/'`
        wireshark_plugins_path=`find $wireshark_library_path -name $wireshark_pattern_plugin -printf %h`
    fi
    echo "$wireshark_plugins_path"

    echo -n "Checking whether OS is 32-bit or 64-bit ... "
    if [ -z "$bits" ]; then
        bits=`getconf LONG_BIT`
    fi
    echo $bits
    case $bits in
        32 | 64 ) : ;;
        * ) echo "Unsupported number of bits '$bits'" ; exit 1 ;;
    esac
    
    echo -n "Copying plug-ins '$wireshark_plugins_path_local/$bits/{$wireshark_plugin1|$wireshark_plugin2}' to '$wireshark_plugins_path'... "
    test -d "$wireshark_plugins_path_local/$bits" || { echo "Plug-ins' source directory '$wireshark_plugins_path_local' doesn't exist" ; exit 1; }
    test -e "$wireshark_plugins_path_local/$bits/$wireshark_plugin1" \
        || { echo "Plug-in file '$wireshark_plugins_path_local/$bits/$wireshark_plugin1' doesn't exist" ; exit 1; }
    test -e "$wireshark_plugins_path_local/$bits/$wireshark_plugin2" \
        || { echo "Plug-in file '$wireshark_plugins_path_local/$bits/$wireshark_plugin2' doesn't exist" ; exit 1; }
    cp "$wireshark_plugins_path_local/$bits/$wireshark_plugin1" "$wireshark_plugins_path_local/$bits/$wireshark_plugin2" "$wireshark_plugins_path" \
        || { echo "Try to run script as root (via 'sudo')" ; exit 1; }
    echo "done"

    echo -n "Copying '$logcnv_binary' to '$logcnv_path'... "
    test -d "$logcnv_path_local" || { echo "source directory '$logcnv_path_local' doesn't exist" ; exit 1; }
    test -e "$logcnv_path_local/$logcnv_binary" \
        || { echo "File '$logcnv_path_local/$logcnv_binary' doesn't exist" ; exit 1; }
    test -d "$logcnv_path" || { echo "destination directory '$logcnv_path' doesn't exist" ; exit 1; }
    install -c "$logcnv_path_local/$logcnv_binary" "$logcnv_path"
    echo "done"

    echo -n "Copying '$rtlogger_binary' to '$rtlogger_path'... "
    test -d "$rtlogger_path_local" || { echo "source directory '$rtlogger_path_local' doesn't exist" ; exit 1; }
    test -e "$rtlogger_path_local/$rtlogger_binary" \
        || { echo "File '$rtlogger_path_local/$rtlogger_binary' doesn't exist" ; exit 1; }
    test -d "$rtlogger_path" || { echo "destination directory '$rtlogger_path' doesn't exist" ; exit 1; }
    install -c "$rtlogger_path_local/$rtlogger_binary" "$rtlogger_path"
    echo "done"
}

while [ "$1" != "" ]; do
    case $1 in
        -v | --version )
            echo "RTLogger installation script $script_version"
            exit 0
            ;;
        -h | --help )
            usage
            ;;
        -w | --wireshark-binary )
            shift
            wireshark_command=$1
            ;;
        -p | --wireshark-plugins-path ) 
            shift
            wireshark_plugins_path=$1
            ;;
        -e | --wireshark-version-path ) 
            shift
            wireshark_version=$1
            ;;
        -l | --logcnv-binary-path )
            shift
            logcnv_path=$1
            ;;
        -r | --rtlogger-binary-path )
            shift
            rtlogger_path=$1
            ;;
        -b | --bits )
            shift
            bits=$1
            ;;
        * )
            usage
            ;;
    esac
    shift
done

do_install

exit 0
